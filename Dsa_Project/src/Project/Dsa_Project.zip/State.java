package Project;

public class State {
    String stateName;
    int distanceFromDelhi;
    int averageTime;

    public State(String stateName, int distanceFromDelhi, int averageTime) {
        this.stateName = stateName;
        this.distanceFromDelhi = distanceFromDelhi;
        this.averageTime = averageTime;
    }
}

